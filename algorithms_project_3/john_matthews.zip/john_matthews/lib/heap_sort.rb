require_relative "heap"

class Array
  def heap_sort!
  end
end
